import SwiftUI
import UIKit
import AVFoundation

// Help and settings for teachers (opens only after pressing the gear for 1 s).
// Everything is kept on this device (AppSettings in UserDefaults, the Mappe in the app's documents); the only network
// access is the version check (UpdateCheck.swift, reads one file, can be switched off).

struct SettingsView: View {
    @ObservedObject var app: AppState
    @State private var askDeleteAll = false
    /// Read once when the sheet appears (listing the voices takes a moment).
    @State private var voiceInfo = ""
    /// The file of the "Fehlersuche" button, once made.
    @State private var diagnosisURL: URL? = nil
    /// Selbsttest: its progress while it runs, and the package once made.
    @State private var selfTestStatus: SelfTestStatus? = nil
    @State private var selfTestURL: URL? = nil
    /// Papierkorb: the entry to delete for good (asked first), and the question "leeren?".
    @State private var purgeItem: TrashItem? = nil
    @State private var askEmptyTrash = false

    var body: some View {
        NavigationStack {
            Form {
                versionSection
                readingSection
                pageSection
                toolsSection
                HandinSettingsSection(handin: app.handin)
                answerSection
                mappeSection
                trashSection
                helpSection
                sharingSection
                privacySection
                voiceSection
                diagnosisSection
            }
            .navigationTitle("Hilfe und Einstellungen")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Fertig") {
                        app.showSettings = false
                    }
                    .font(.headline)
                }
            }
        }
        .onAppear {
            voiceInfo = settingsVoiceDescription()
            app.store.purgeOldTrash()
        }
    }

    // MARK: - Settings

    @MainActor
    private var readingSection: some View {
        Section {
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Text("Sprechtempo")
                    Spacer()
                    Text(settingsPercent(app.settings.rate))
                        .foregroundColor(.secondary)
                }
                HStack(spacing: 12) {
                    Image(systemName: "tortoise.fill")
                        .foregroundColor(.secondary)
                    Slider(value: $app.settings.rate, in: 0.5...1.3, step: 0.05, onEditingChanged: { editing in
                        if !editing {
                            app.say("So schnell lese ich vor.")
                        }
                    })
                    Image(systemName: "hare.fill")
                        .foregroundColor(.secondary)
                }
            }
            .padding(.vertical, 4)
            Button(action: {
                app.say("Hallo! Ich lese dir das Arbeitsblatt vor. Tippe auf ein Wort.")
            }) {
                SwiftUI.Label("Stimme anhören", systemImage: "speaker.wave.2.fill")
            }
            Toggle("Ansagen", isOn: $app.settings.announce)
            VStack(alignment: .leading, spacing: 10) {
                Text("Lückenton")
                Picker("Lückenton", selection: $app.settings.tone) {
                    ForEach(ToneKind.allCases) { kind in
                        Text(kind.title).tag(kind)
                    }
                }
                .pickerStyle(.segmented)
                .labelsHidden()
            }
            .padding(.vertical, 4)
            .onChange(of: app.settings.tone) { _, _ in
                // (AppState has already handed the new tone to the speaker)
                app.speaker.playTone()
            }
            Button(action: {
                app.speaker.playTone()
            }) {
                SwiftUI.Label("Ton anhören", systemImage: "bell.fill")
            }
        } header: {
            Text("Vorlesen")
        } footer: {
            // (verbatim: a "%" in a localized key would be read as a format sign)
            Text(verbatim: "100 % ist das normale Tempo des iPads. Ansagen: Beim Wählen eines Werkzeugs wird sein Name gesagt (z. B. „Markieren“), dazu kurze Meldungen. Der Lückenton steht im vorgelesenen Satz für eine leere Lücke.")
        }
    }

    @MainActor
    private var pageSection: some View {
        Section {
            Toggle("Wort-Umrandungen", isOn: $app.settings.outlines)
            Toggle("Kästen zusammen vorlesen", isOn: $app.settings.boxesTogether)
            Toggle("Lücken markieren", isOn: $app.settings.markGaps)
            Toggle("Foto-Hinweis vor der Kamera", isOn: $app.settings.photoHelp)
            Toggle("Apples Dokument-Kamera verwenden", isOn: $app.settings.appleCamera)
            Toggle("Vor dem Abgeben der Lehrkraft zeigen", isOn: $app.settings.showTeacherFirst)
            Toggle("AirDrop-Knöpfe bei „Fertig“", isOn: $app.settings.airDrop)
        } header: {
            Text("Blatt und Foto")
        } footer: {
            Text("Wort-Umrandungen: dünne Rahmen um erkannte Wörter. Kästen zusammen: Ein Wort in einem gedruckten Kasten liest den ganzen Kasten, dasselbe Wort noch einmal angetippt nur dieses Wort. Lücken markieren: Schreiblinien und Kästchen lila zeigen. Foto-Hinweis: kurze Bildanleitung (Heft flach, iPad gerade darüber, ganzes Blatt) vor jedem Foto. Der Lehrkraft zeigen: Bei „Fertig“ erscheint zuerst ein Daumen-Knopf; erst danach kann das Kind abgeben. AirDrop-Knöpfe: kleine Knöpfe unter „Abgeben“, um die PDF zusätzlich per AirDrop zu schicken. Kamera: Normal nimmt das Hörblatt seine eigene, einfache Kamera (löst von selbst aus, sobald das Blatt ruhig im Bild ist, großer Knopf, kein „Sichern“). Apples Dokument-Kamera braucht „Behalten“ und „Sichern“.")
        }
    }

    @MainActor
    private var answerSection: some View {
        Section {
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Text("Abstand zwischen den Wörtern")
                    Spacer()
                    Text(String(format: "%.1f×", app.settings.answerWordSpacing))
                        .foregroundColor(.secondary)
                        .monospacedDigit()
                }
                Slider(value: $app.settings.answerWordSpacing, in: 1...4, step: 0.25)
                // (a sample, written as the answers are)
                SettingsSpacingSample(spacing: app.settings.answerWordSpacing)
                    .frame(height: 36)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 6)
                    .background(RoundedRectangle(cornerRadius: 8).fill(Color(red: 237 / 255, green: 233 / 255, blue: 254 / 255)))
                    .accessibilityHidden(true)
            }
            Toggle("Mikrofon-Knopf", isOn: $app.settings.mic)
            if app.settings.mic && app.listener.blocked {
                HStack(alignment: .top, spacing: 10) {
                    Image(systemName: "mic.slash.fill")
                        .foregroundColor(.orange)
                    Text("Das Mikrofon oder die Spracherkennung ist nicht erlaubt oder nicht verfügbar. Das Kind antwortet deshalb über die Tastatur. Erlauben: iPad-Einstellungen → Datenschutz & Sicherheit → Mikrofon bzw. Spracherkennung.")
                        .font(.callout)
                        .foregroundColor(.secondary)
                }
            }
        } header: {
            Text("Antworten")
        } footer: {
            Text("Abstand: Wie weit die gesprochenen Wörter auseinanderstehen – das Kind sieht, wo ein Wort aufhört, und kann zwischen zwei Wörter tippen, um dort etwas einzufügen. Mikrofon-Knopf an: Das Hörblatt hört nach dem Antippen einer Lücke selbst zu. Aus: Die Antwort kommt über die Tastatur, mit ihrer Diktier-Taste (Mikrofon unten auf der Tastatur).")
        }
    }

    /// Fehlersuche: a file about the open page for the developer.
    @MainActor
    private var diagnosisSection: some View {
        Section {
            Button(action: {
                if let c = app.active {
                    diagnosisURL = Diagnosis.file(for: c, app: app)
                }
            }) {
                SwiftUI.Label("Datei zur offenen Seite erstellen", systemImage: "ladybug")
            }
            .disabled(app.active == nil)
            if let url = diagnosisURL {
                ShareLink(item: url) {
                    SwiftUI.Label("Datei teilen", systemImage: "square.and.arrow.up")
                }
            }
            Button(action: {
                if let hid = app.active?.page.heft { startSelfTest(.heft(hid)) }
            }) {
                SwiftUI.Label("Selbsttest: ganzes Heft prüfen", systemImage: "checklist")
            }
            .disabled(app.active?.page.heft == nil || selfTestStatus != nil)
            Button(action: {
                if let c = app.active, c.page.heft == nil { startSelfTest(.photo(c.page.id)) }
            }) {
                SwiftUI.Label("Selbsttest: offenes Foto prüfen", systemImage: "camera")
            }
            .disabled(app.active == nil || app.active?.page.heft != nil || selfTestStatus != nil)
            Button(action: { startSelfTest(.allPhotos) }) {
                SwiftUI.Label("Selbsttest: alle Fotos prüfen", systemImage: "photo.on.rectangle")
            }
            .disabled(!app.store.pages.contains(where: { $0.heft == nil }) || selfTestStatus != nil)
            if let st = selfTestStatus {
                VStack(alignment: .leading, spacing: 6) {
                    Text(st.message)
                    ProgressView(value: st.progress)
                }
            }
            if let url = selfTestURL {
                ShareLink(item: url) {
                    SwiftUI.Label("Selbsttest teilen", systemImage: "square.and.arrow.up")
                }
            }
        } header: {
            Text("Fehlersuche")
        } footer: {
            Text("Die Datei beschreibt, wie das Hörblatt die offene Seite gelesen hat (Wörter, ihre Lage, Kästen, Lücken, Sätze). Antworten, Markierungen und Stiftstriche sind nicht darin. Sie hilft, Fehler beim Vorlesen zu finden. Der Selbsttest geht alle Seiten des offenen Hefts (oder das offene Foto, oder alle Fotos) durch, tippt jedes Wort und jede Lücke an und packt alles mit den Bildern der Seiten in eine ZIP-Datei. Achtung: Fotos zeigen das Blatt so, wie es fotografiert wurde – auch Handschrift, z. B. den Namen des Kindes. Für den Foto-Test am besten leere Blätter nehmen.")
        }
    }

    @MainActor
    private func startSelfTest(_ scope: SelfTestScope) {
        guard selfTestStatus == nil else { return }
        selfTestURL = nil
        selfTestStatus = SelfTestStatus(message: "Selbsttest startet …", progress: 0)
        Task { @MainActor in
            let url = await SelfTest.run(scope, app: app) { st in
                selfTestStatus = st
            }
            selfTestStatus = nil
            selfTestURL = url
            app.announce(url == nil ? "Der Selbsttest hat nicht geklappt." : "Der Selbsttest ist fertig.")
        }
    }

    @MainActor
    private var mappeSection: some View {
        Section {
            HStack(spacing: 10) {
                Image(systemName: "folder.fill")
                    .foregroundColor(SettingsStyle.teal)
                Text(settingsPageCount(app.store.pages.count))
            }
            Button(action: {
                // (the settings close, then the Fotos app opens)
                app.showPicker = true
            }) {
                SwiftUI.Label("Foto aus der Fotos-App wählen", systemImage: "photo.on.rectangle")
            }
            Button(role: .destructive, action: {
                app.saveOpenPages(stopping: false)
                askDeleteAll = true
            }) {
                SwiftUI.Label("Alle Seiten löschen", systemImage: "trash")
            }
            .disabled(app.store.pages.isEmpty)
            .confirmationDialog("Alle Seiten der Mappe löschen?", isPresented: $askDeleteAll, titleVisibility: .visible) {
                Button("Alle Seiten löschen", role: .destructive) {
                    app.store.deleteAll()
                }
                Button("Abbrechen", role: .cancel) {
                }
            } message: {
                Text("Alle Seiten und Hefte kommen mit ihren Antworten in den Papierkorb. Dort lassen sie sich \(PageStore.trashDays) Tage lang zurückholen, danach werden sie endgültig gelöscht.")
            }
        } header: {
            Text("Mappe")
        } footer: {
            Text("Jede fotografierte Seite bleibt mit allen Antworten in der Mappe. Eine einzelne Seite löscht man in der Mappe: lange auf die Seite drücken, dann auf den roten Papierkorb. Gelöschtes kommt in den Papierkorb (unten). „Foto aus der Fotos-App wählen“ liest ein vorhandenes Foto (z. B. ein Tafelbild) wie ein neues; das Kind sieht diesen Knopf nicht. Was das Kind sieht, regelt der Schrank (in der Mappe den Schrank-Knopf 1 Sekunde drücken).")
        }
    }

    // MARK: - Papierkorb

    @MainActor
    private var trashSection: some View {
        Section {
            if app.store.trash.isEmpty {
                Text("Der Papierkorb ist leer.")
                    .foregroundColor(.secondary)
            }
            ForEach(app.store.trash) { item in
                HStack(spacing: 12) {
                    if let thumb = app.store.trashThumbnail(item) {
                        Image(uiImage: thumb)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 44, height: 56)
                            .clipShape(RoundedRectangle(cornerRadius: 4))
                    } else {
                        Image(systemName: item.heft != nil ? "book.closed" : "doc")
                            .frame(width: 44, height: 56)
                    }
                    VStack(alignment: .leading, spacing: 2) {
                        Text(settingsTrashTitle(item))
                            .lineLimit(2)
                        Text(settingsTrashDate(item, daysLeft: app.store.daysLeft(item)))
                            .font(.footnote)
                            .foregroundColor(.secondary)
                    }
                    Spacer(minLength: 8)
                    Button(action: {
                        app.store.restore(item.id)
                        // a Heft still being read goes on reading
                        app.readMissingHeftPages()
                    }) {
                        SwiftUI.Label("Zurückholen", systemImage: "arrow.uturn.backward")
                    }
                    .buttonStyle(.borderless)
                    Button(role: .destructive, action: {
                        purgeItem = item
                    }) {
                        Image(systemName: "trash")
                    }
                    .buttonStyle(.borderless)
                    .accessibilityLabel("Endgültig löschen")
                }
            }
            if !app.store.trash.isEmpty {
                Button(role: .destructive, action: {
                    askEmptyTrash = true
                }) {
                    SwiftUI.Label("Papierkorb leeren", systemImage: "trash.slash")
                }
            }
        } header: {
            Text("Papierkorb")
        } footer: {
            Text("Gelöschte Seiten und Hefte bleiben \(PageStore.trashDays) Tage hier und werden danach automatisch endgültig gelöscht. Zurückholen bringt sie mit allen Antworten in die Mappe. Nur hier in den Einstellungen sichtbar.")
        }
        .confirmationDialog("Endgültig löschen?", isPresented: Binding(get: { purgeItem != nil },
                                                                     set: { if !$0 { purgeItem = nil } }),
                            titleVisibility: .visible) {
            Button("Endgültig löschen", role: .destructive) {
                if let item = purgeItem { app.store.purge(item.id) }
                purgeItem = nil
            }
            Button("Abbrechen", role: .cancel) {
                purgeItem = nil
            }
        } message: {
            Text("„\(purgeItem.map { settingsTrashTitle($0) } ?? "")“ wird von diesem iPad gelöscht. Das lässt sich nicht rückgängig machen.")
        }
        .confirmationDialog("Papierkorb leeren?", isPresented: $askEmptyTrash, titleVisibility: .visible) {
            Button("Papierkorb leeren", role: .destructive) {
                app.store.emptyTrash()
            }
            Button("Abbrechen", role: .cancel) {
            }
        } message: {
            Text("Alles im Papierkorb wird von diesem iPad gelöscht. Das lässt sich nicht rückgängig machen.")
        }
    }

    // MARK: - Help

    /// Which version is installed (to compare with the developer's message after an update).
    @MainActor
    private var versionSection: some View {
        Section {
            HStack(spacing: 12) {
                Image(systemName: "number.circle.fill")
                    .font(.title2)
                    .foregroundColor(SettingsStyle.teal)
                VStack(alignment: .leading, spacing: 2) {
                    Text("Version \(BuildInfo.number)")
                        .font(.headline)
                    Text(BuildInfo.date + " · Erkennung \(Recognizer.version)")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            UpdateRows(updates: app.updates, enabled: $app.settings.updateCheck)
        } header: {
            Text("Installierte Version")
        } footer: {
            Text("Die Suche liest nur eine kleine Datei mit der neuesten Versionsnummer von GitHub; vom iPad wird nichts gesendet. Gibt es eine neue Version, zeigt das Zahnrad einen blauen Punkt.")
        }
    }

    /// Each tool on or off (the child works on paper; the iPad mostly reads). "Wort" always stays.
    @MainActor
    private var toolsSection: some View {
        Section {
            ForEach(ToolKey.allCases) { t in
                Toggle(t.title, isOn: Binding(
                    get: { app.settings.shows(t) },
                    set: { app.settings.setShows(t, $0) }
                ))
            }
        } header: {
            Text("Werkzeuge zeigen")
        } footer: {
            Text("Ausgeschaltete Werkzeuge verschwinden aus der Leiste unten (▶ oben links auf der Seite). „Wort vorlesen“ bleibt immer. Ohne „Sprechen“ startet das Antippen einer Lücke kein Mikrofon mehr, die Lücke wird nur vorgelesen; ohne „Stift“ sagen Ankreuz-Kästchen nur ihre Beschriftung.")
        }
    }

    @MainActor
    private var helpSection: some View {
        Section {
            SettingsStepRow(number: "1", symbol: "camera.fill", color: SettingsStyle.teal, title: "Foto",
                            text: "Die Kamera des Hörblatts umrandet das Blatt und löst von selbst aus, sobald das iPad still darüber gehalten wird (oder mit dem großen runden Knopf). Ist das Foto zu dunkel, verwackelt oder kaum lesbar, fragt das Hörblatt: „Nochmal“ (Kamera) oder „Weiter“ (Pfeil). Die Schrift wird auf dem iPad erkannt. Ein kurzer Foto-Hinweis vorher und Apples Dokument-Kamera lassen sich oben unter „Blatt und Foto“ einschalten.")
            SettingsStepRow(number: "2", symbol: "hand.tap.fill", color: SettingsStyle.orange, title: "Wort und Satz",
                            text: "Wort antippen: Nur dieses Wort wird vorgelesen. Zweiter Knopf: der ganze Satz, auch über Zeilen hinweg. Wörter in gedruckten Kästen: der ganze Kasten. Lücken sind lila; im Satz steht für eine leere Lücke ein kurzer Ton, eine ausgefüllte wird mitgelesen. Eine leere Lücke antippen öffnet sofort das Antwortfeld und das Hörblatt hört zu (auch bei Wort und Satz); leere Tabellenzellen sagen vorher ihre Spaltenüberschrift. Eine ausgefüllte Lücke wird vorgelesen.")
            SettingsStepRow(number: "3", symbol: "mic.fill", color: SettingsStyle.lila, title: "Sprechen",
                            text: "Eine Lücke oder eine beliebige Stelle antippen: Es öffnet sich ein Antwortfeld, das Hörblatt hört zu. Der lila Lautsprecher liest die Antwort vor (jedes Wort leuchtet mit), das Mikrofon nimmt sie neu auf, das Häkchen schließt das Feld. Gesprochene Antworten verhalten sich wie gedruckter Text: Mit „Wort“ liest ein angetipptes Wort nur dieses Wort, mit „Satz“ den ganzen Satz; Markieren und Wort-Lupe gehen auch darin. Korrigieren mit „Sprechen“: auf ein Wort tippen und neu sprechen – nur dieses Wort wird ersetzt; zwischen zwei Wörter oder ans Ende tippen (roter Strich) – das Gesprochene wird dort eingefügt. In jedem Werkzeug geht auch: Finger kurz auf dem Wort lassen, nach dem „Pling“ neu sprechen. Der Radiergummi auf einem Wort löscht nur dieses Wort, nie die ganze Antwort.")
            SettingsStepRow(number: "4", symbol: "highlighter", color: SettingsStyle.amber, title: "Markieren",
                            text: "Farbe wählen (gelb, grün, blau, orange). Wort antippen oder waagerecht über Wörter wischen. Für einen Wortteil den Finger kurz auf dem Wort liegen lassen: Die Wort-Lupe zeigt das Wort groß in Buchstaben, Wischen über die Buchstaben markiert genau diese. Die Seite verschiebt man dabei mit zwei Fingern.")
            SettingsStepRow(number: nil, symbol: "pencil.tip", color: SettingsStyle.slate, title: "Stift",
                            text: "Freihand zum Verbinden, Ankreuzen, Einkreisen und Durchstreichen, in Blau, Rot oder Schwarz. Radiergummi: Wörter in Antworten (einzeln), Markierungen, Stiftstriche und falsch erkannte Lücken. Der Pfeil nimmt den letzten Schritt zurück.")
            SettingsStepRow(number: nil, symbol: "square.and.pencil", color: SettingsStyle.lila, title: "Schreibblatt",
                            text: "In der Mappe „Schreibblatt“: eine leere weiße Seite ohne Linien zum freien Schreiben. Das Kind tippt mit „Sprechen“ darauf und spricht; der Text läuft von oben nach unten weiter. Einfügen, Löschen, Markieren, Stift und Abgeben wie bei jedem Blatt.")
            SettingsStepRow(number: "5", symbol: "checkmark.square.fill", color: SettingsStyle.blue, title: "Fertig",
                            text: "Das Blatt mit allen Antworten, Markierungen und Stiftstrichen. Das Kind zeigt es zuerst der Lehrkraft und tippt auf den Daumen. Dann tippt es auf „Abgeben“: Die PDF wird im Abgabe-Ordner auf diesem iPad gespeichert (neue Datei mit Datum und Uhrzeit; auf einer Heftseite das ganze Heft). Darunter, wenn eingeschaltet, kleine AirDrop-Knöpfe: diese Seite, das ganze Heft oder „Alle von heute“ (alle heute fotografierten Seiten in einer PDF).")
            SettingsStepRow(number: nil, symbol: "folder.fill", color: SettingsStyle.teal, title: "Mappe und zwei Seiten",
                            text: "Jede Seite bleibt mit allen Antworten gespeichert. Das Kind sieht in der Mappe (Ordner oben links) und oben in der Leiste nur, was heute ausgegeben ist: ein Tipp wechselt die Seite. Im Querformat zeigt der Knopf mit den zwei Rechtecken zwei Seiten nebeneinander, z. B. links das Buch und rechts das Arbeitsblatt. Die zuletzt berührte Seite hat einen türkisen Rahmen; eine Seite aus der Mappe oder der Leiste öffnet sich dort. Löschen: eine Seite in der Mappe oder in der Leiste lange drücken, dann der rote Papierkorb.")
            SettingsStepRow(number: nil, symbol: "book.fill", color: SettingsStyle.teal, title: "Heft (PDF)",
                            text: "Eine PDF (z. B. ein Ermittlerheft) per AirDrop aufs iPad schicken oder in der Dateien-App ablegen. Im Schrank (in der Mappe den Schrank-Knopf 1 Sekunde drücken) „PDF öffnen“ tippen und die Datei wählen. Die erste Seite wird sofort gelesen und geöffnet, die übrigen liest das Hörblatt im Hintergrund weiter (kleiner Kreisel unter der Seite, geht auch nach einem Neustart weiter). Blättert das Kind zu einer noch nicht gelesenen Seite, kommt sie sofort dran. Das Heft liegt danach als ein Eintrag in der Mappe und öffnet sich auf der zuletzt bearbeiteten Seite; unten blättern große Pfeile. Bei „Fertig“ gibt das Kind das ganze Heft als PDF ab; per AirDrop geht auch nur diese Seite.")
            SettingsStepRow(number: nil, symbol: "archivebox.fill", color: SettingsStyle.slate, title: "Schrank (nur Lehrkräfte)",
                            text: "In der Mappe oben rechts den Schrank-Knopf 1 Sekunde drücken. Im Schrank liegt alles, was gerade nicht beim Kind ist. „Ausgeben“ legt eine Seite oder ein Heft in die Mappe des Kindes, „Weglegen“ zurück in den Schrank; nach rechts wischen öffnet sie sofort. Neue Fotos, PDFs und Schreibblätter liegen gleich beim Kind. Am Ende des Tages kommt alles von selbst in den Schrank, die Antworten bleiben. Für mehrere Lehrkräfte: Fächer anlegen und Seiten zuordnen (Etikett-Knopf); das Kind sieht keine Fächer. „PDF öffnen“ und „Foto aus der Fotos-App“ gibt es im Schrank.")
        } header: {
            Text("So geht es")
        } footer: {
            Text("Diese Seite öffnet sich nur, wenn man das Zahnrad 1 Sekunde lang drückt.")
        }
    }

    @MainActor
    private var sharingSection: some View {
        Section {
            Text("Normal gibt das Kind mit „Abgeben“ ab: Die PDF liegt danach im Abgabe-Ordner (siehe oben) in der Dateien-App dieses iPads.")
                .font(.callout)
            Text("Zusätzlich per AirDrop: Auf dem Lehrer-iPad Einstellungen → Allgemein → AirDrop → „Für alle für 10 Minuten“. Das Kind tippt bei „Fertig“ auf einen kleinen Knopf mit dem AirDrop-Zeichen, dann auf AirDrop und auf das Lehrer-iPad. Erscheint ein Code, gibt das Kind ihn ein.")
                .font(.callout)
        } header: {
            Text("Abgabe und AirDrop")
        }
    }

    @MainActor
    private var privacySection: some View {
        Section {
            Text("Fotos, Antworten, Markierungen und Stiftstriche bleiben auf diesem iPad (ohne iCloud-Sicherung). Die Texterkennung läuft auf dem Gerät; es wird nichts hochgeladen. Abgegebene PDFs liegen in dem Ordner, den Sie gewählt haben – ist das ein Cloud-Ordner, auch dort. Ins Internet geht die App nur für die Suche nach einer neuen Version (oben, abschaltbar): Sie liest eine Datei von GitHub und sendet nichts.")
                .font(.callout)
            Text("Ausnahme: Gesprochene Antworten erkennt Apple wie beim Tastatur-Diktat. Kann das iPad die Sprache nicht selbst erkennen, geschieht das gegebenenfalls auf Servern von Apple.")
                .font(.callout)
        } header: {
            Text("Datenschutz")
        }
    }

    @MainActor
    private var voiceSection: some View {
        Section {
            HStack(spacing: 10) {
                Image(systemName: "person.wave.2.fill")
                    .foregroundColor(SettingsStyle.teal)
                Text(voiceInfo.isEmpty ? "Stimme wird gesucht …" : voiceInfo)
            }
            Text("Das Hörblatt nimmt die beste deutsche Stimme des iPads. Eine natürlicher klingende Stimme laden: iPad-Einstellungen → Bedienungshilfen → Gesprochene Inhalte → Stimmen → Deutsch, dort z. B. eine Stimme mit „(Premium)“ oder „(Erweitert)“ laden. Danach das Hörblatt neu starten.")
                .font(.callout)
        } header: {
            Text("Stimme")
        }
    }
}

// MARK: - Helpers

/// A sample answer written with the chosen room between the words (as on the page).
fileprivate struct SettingsSpacingSample: UIViewRepresentable {
    let spacing: Double

    func makeUIView(context: Context) -> UILabel {
        let label = UILabel()
        label.numberOfLines = 1
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        return label
    }

    func updateUIView(_ label: UILabel, context: Context) {
        // (the sample follows the slider at once, before the settings reach AnswerStyle)
        let saved = AnswerStyle.wordSpacing
        AnswerStyle.wordSpacing = CGFloat(spacing)
        label.attributedText = answerAttributed("Der Prinz ritt durch den Wald.", font: answerUIFont(22),
                                                color: UIColor(red: 0.11, green: 0.25, blue: 0.69, alpha: 1))
        AnswerStyle.wordSpacing = saved
    }
}

/// One step of the picture card: number and symbol in the card's colour, then what it does.
fileprivate struct SettingsStepRow: View {
    let number: String?
    let symbol: String
    let color: Color
    let title: String
    let text: String

    var body: some View {
        HStack(alignment: .top, spacing: 14) {
            ZStack(alignment: .topLeading) {
                RoundedRectangle(cornerRadius: 10)
                    .fill(color)
                Image(systemName: symbol)
                    .font(.system(size: 20, weight: .semibold))
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                if let n = number {
                    Text(n)
                        .font(.system(size: 10, weight: .heavy))
                        .foregroundColor(color)
                        .frame(width: 15, height: 15)
                        .background(Circle().fill(Color.white))
                        .padding(2)
                }
            }
            .frame(width: 44, height: 44)
            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.headline)
                Text(text)
                    .font(.callout)
                    .foregroundColor(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .padding(.vertical, 4)
    }
}

/// Colours of the picture card.
fileprivate enum SettingsStyle {
    static let teal = Color(red: 15.0 / 255, green: 118.0 / 255, blue: 110.0 / 255)
    static let orange = Color(red: 234.0 / 255, green: 88.0 / 255, blue: 12.0 / 255)
    static let lila = Color(red: 124.0 / 255, green: 58.0 / 255, blue: 237.0 / 255)
    static let amber = Color(red: 217.0 / 255, green: 119.0 / 255, blue: 6.0 / 255)
    static let slate = Color(red: 71.0 / 255, green: 85.0 / 255, blue: 105.0 / 255)
    static let blue = Color(red: 37.0 / 255, green: 99.0 / 255, blue: 235.0 / 255)
}

/// 0.85 → "85 %".
fileprivate func settingsPercent(_ rate: Double) -> String {
    let p = Int((rate * 100).rounded())
    return "\(p) %"
}

fileprivate func settingsPageCount(_ n: Int) -> String {
    if n == 0 { return "Die Mappe ist leer" }
    if n == 1 { return "1 Seite in der Mappe" }
    return "\(n) Seiten in der Mappe"
}

/// The voice the speaker picks (same order: premium, enhanced, the system's German voice).
fileprivate func settingsVoiceDescription() -> String {
    let german = AVSpeechSynthesisVoice.speechVoices().filter { $0.language == "de-DE" }
    var best: AVSpeechSynthesisVoice? = german.first(where: { $0.quality == .premium })
    if best == nil {
        best = german.first(where: { $0.quality == .enhanced })
    }
    if best == nil {
        best = AVSpeechSynthesisVoice(language: "de-DE")
    }
    guard let v = best else { return "Keine deutsche Stimme gefunden" }
    var kind = "einfache Qualität"
    if v.quality == .premium {
        kind = "Premium"
    } else if v.quality == .enhanced {
        kind = "Erweitert"
    }
    let count = german.count
    let installed = count == 1 ? "1 deutsche Stimme" : "\(count) deutsche Stimmen"
    return "Jetzt: \(v.name) (\(kind)) · \(installed) auf dem iPad"
}

// MARK: - Papierkorb texts

fileprivate func settingsTrashTitle(_ item: TrashItem) -> String {
    if let h = item.heft {
        let n = h.pageTotal
        return item.title + " (Heft, " + (n == 1 ? "1 Seite" : "\(n) Seiten") + ")"
    }
    return item.title
}

fileprivate func settingsTrashDate(_ item: TrashItem, daysLeft: Int) -> String {
    let f = DateFormatter()
    f.locale = Locale(identifier: "de_DE")
    f.dateFormat = "d. MMMM"
    let left: String
    switch daysLeft {
    case 0: left = "wird heute endgültig gelöscht"
    case 1: left = "noch 1 Tag"
    default: left = "noch \(daysLeft) Tage"
    }
    return "Gelöscht am " + f.string(from: item.deleted) + " · " + left
}
